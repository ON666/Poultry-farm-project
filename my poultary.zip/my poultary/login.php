<?php
session_start();
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle login form submission
    $username = $_POST["username"];
    $password = $_POST["password"];
    
    // Your authentication logic here, for simplicity, I'm just checking if username and password match
    if($username === "your_username" && $password === "your_password") {
        $_SESSION['username'] = $username;
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Invalid username or password.";
    }
}
?>