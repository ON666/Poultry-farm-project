<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Employee Dashboard</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f0f0f0;
    }

    .container {
        max-width: 400px;
        margin: 50px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        animation: slideIn 0.5s ease-out;
    }

    .input-group {
        margin-bottom: 20px;
    }

    .input-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }

    .input-group input {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
    }

    .input-group input:focus {
        outline: none;
        border-color: #007bff;
    }

    .btn {
        display: block;
        width: 100%;
        padding: 10px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .btn:hover {
        background-color: #0056b3;
    }

    .dashboard {
        display: none;
        animation: slideIn 0.5s ease-out;
    }

    .employee-details {
        margin-top: 20px;
        padding: 20px;
        background-color: #f9f9f9;
        border-radius: 5px;
    }

    .employee-details h3 {
        margin-top: 0;
    }

    .employee-details p {
        margin: 5px 0;
    }

    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateY(-50px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
</style>
</head>
<body>
<?php
session_start();
if(isset($_SESSION['username'])) {
    $servername = "localhost";
    $username = "your_username"; // Replace with your MySQL username
    $password = "your_password"; // Replace with your MySQL password
    $dbname = "your_database"; // Replace with your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch employee details based on username
    $username = $_SESSION['username'];
    $sql = "SELECT * FROM employees WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $username = $row["username"]
        $employee_name = $row["name"];
        $employee_id = $row["employee_id"];
        $gender = $row["gender"]
        $phone = $row["phone"]
        $dob = $row["dob"];
        $jd = $row["jd"];
        $address = $row["address"];
        $salary_received_date = $row["salary_received_date"];
        $task = $row["task"];

        // You can fetch more details as needed
    }

    $conn->close();
}
?>
<div class="container" id="login-container" <?php if(isset($_SESSION['username'])) echo 'style="display: none;"'; ?>>
    <h2>Login</h2>
    <form method="post" action="login.php">
        <div class="input-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" placeholder="Enter your username">
        </div>
        <div class="input-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Enter your password">
        </div>
        <button type="submit" class="btn">Login</button>
    </form>
</div>

<div class="dashboard" id="dashboard-container" <?php if(isset($_SESSION['username'])) echo 'style="display: block;"'; ?>>
    <h2>Welcome, <?php if(isset($username)) echo $username; ?></h2>
    <div class="employee-details">
        <h3>Employee Details</h3>
        <p><strong>Employee ID:</strong> <?php if(isset($employee_id)) echo $employee_id; ?></p>
        <p><strong>Name:</strong> <?php if(isset($employee_name)) echo $employee_name; ?></p>
        <p><strong>Gender:</strong> <?php if(isset($gender)) echo $gender; ?></p>
        <p><strong>Contact No:</strong> <?php if(isset($phone)) echo $phone; ?></p>  
        <p><strong>DOB:</strong> <?php if(isset($dob)) echo $dob; ?></p>
        <p><strong>Joining Date:</strong> <?php if(isset($jd)) echo $jd; ?></p>
        <p><strong>Address:</strong> <?php if(isset($address)) echo $address; ?></p>
        <p><strong>Salary Received Date:</strong> <?php if(isset($salary_received_date)) echo $salary_received_date; ?></p>
        <p><strong>Task Assigned:</strong> <?php if(isset($task)) echo $task; ?></p>
    </div>
    <form method="post" action="logout.php">
        <button type="submit" class="btn" name="logout">Logout</button>
    </form>
</div>
</body>
</html>
