<?php
// Database configuration
$servername = "localhost"; // Change this to your database server name
$username = "username"; // Change this to your database username
$password = "password"; // Change this to your database password
$database = "dbname"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $zip_code = $_POST['zip_code'];
    $phone_number = $_POST['phone_number'];
    $payment_method = $_POST['payment_method'];

    // Example query to insert form data into a table named 'orders'
    $sql = "INSERT INTO orders (full_name, email, address, city, state, zip_code, phone_number, payment_method) 
            VALUES ('$full_name', '$email', '$address', '$city', '$state', '$zip_code', '$phone_number', '$payment_method')";

    if ($conn->query($sql) === TRUE) {
        // Redirect to index page after successful submission
        header("Location: index.html");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>
