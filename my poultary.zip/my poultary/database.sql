CREATE TABLE employees (
    employee_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL,
    name VARCHAR(100),
    gender VARCHAR(10),
    contact_no VARCHAR(20),
    dob DATE,
    joining_date DATE,
    address VARCHAR(255),
    salary_received_date DATE,
    task_assigned VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    address VARCHAR(255) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    zip_code VARCHAR(20) NOT NULL,
    phone_number VARCHAR(15) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO employees (username, password, name, gender, contact_no, dob, joining_date, address, salary_received_date, task_assigned)
VALUES
    ('sidhu123', 'password123', 'Siddhu ', 'Male', '1234567890', '1990-01-01', '2020-01-01', 'chicken mandi, punjab', '2024-04-01', 'Manage customer inquiries'),
    ('pinder123', 'password456', 'Pinder Rai', 'Female', '9876543210', '1995-05-15', '2021-02-15', 'chicken mandi punjab', '2024-04-01', 'Process orders');
